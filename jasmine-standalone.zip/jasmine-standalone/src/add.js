window.Calculator = { 
   
  currentVal:0,  
  varAfterEachExmaple:0, 
  
  add:function (num1) { 
     this.currentVal += num1; 
     return this.currentVal;    
  },    
  
};