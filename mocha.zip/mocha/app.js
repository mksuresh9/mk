module.exports = {
   add: function (a,b){
    return a+b
},
sub: function (a,b){
    return a-b
},
mul: function (a,b){
    return a*b
}
}